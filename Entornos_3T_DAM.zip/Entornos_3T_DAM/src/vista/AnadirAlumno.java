package vista;

import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;

import controlador.ConexionBD;
import modelo.Alumno;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import java.util.Date;
import java.util.Calendar;
import com.toedter.calendar.JCalendar;
import com.toedter.components.JLocaleChooser;
import com.toedter.calendar.JDateChooser;

public class AnadirAlumno extends JPanel {
	private JTextPane txtAgregarAlumno;
	private JTextField txtNombre, txtApellido1, txtApellido2, txtDNI, txtDireccion, txtTelefono;
	private JLabel lblNombre, lblApellido1, lblApellido2, lblDNI, lblDireccion, lblFechaNacimiento, lblTelefono, lblLogoJUANXXIII;
	private JButton btnAgregar, btnLimpiar;
	
	ConexionBD bd = new ConexionBD();
	Alumno alum = new Alumno();
	private final JDateChooser dateChooser = new JDateChooser();

	/**
	 * Create the panel.
	 */
	public AnadirAlumno() {
		setBackground(Color.WHITE);
		setLayout(null);
		setBounds(100, 100, 800, 500);
		
		lblLogoJUANXXIII = new JLabel("");
		lblLogoJUANXXIII.setIcon(new ImageIcon("img/Logojuan.jpg"));
		lblLogoJUANXXIII.setBounds(385, 53, 389, 360);
		add(lblLogoJUANXXIII);
		
		txtAgregarAlumno = new JTextPane();
		txtAgregarAlumno.setEditable(false);
		txtAgregarAlumno.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 30));
		txtAgregarAlumno.setText("Agregar Alumno");
		txtAgregarAlumno.setBounds(74, 11, 257, 54);
		add(txtAgregarAlumno);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(183, 123, 192, 20);
		add(txtNombre);
		txtNombre.setColumns(10);
		
		txtApellido1 = new JTextField();
		txtApellido1.setColumns(10);
		txtApellido1.setBounds(183, 161, 192, 20);
		add(txtApellido1);
		
		txtApellido2 = new JTextField();
		txtApellido2.setColumns(10);
		txtApellido2.setBounds(183, 199, 192, 20);
		add(txtApellido2);
		
		lblApellido2 = new JLabel("Segundo Apellido:");
		lblApellido2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblApellido2.setBounds(35, 196, 138, 20);
		add(lblApellido2);
		
		lblApellido1 = new JLabel("Primer Apellido:");
		lblApellido1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblApellido1.setBounds(35, 158, 138, 20);
		add(lblApellido1);
		
		lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblNombre.setBounds(35, 120, 138, 20);
		add(lblNombre);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.setBackground(Color.WHITE);
		btnAgregar.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		btnAgregar.setBounds(35, 378, 116, 35);
		add(btnAgregar);
		
		btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		btnLimpiar.setBackground(Color.WHITE);
		btnLimpiar.setBounds(230, 378, 116, 35);
		add(btnLimpiar);
		
		lblDNI = new JLabel("DNI:");
		lblDNI.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblDNI.setBounds(35, 230, 138, 20);
		add(lblDNI);
		
		txtDNI = new JTextField();
		txtDNI.setColumns(10);
		txtDNI.setBounds(183, 230, 192, 20);
		add(txtDNI);
		
		lblDireccion = new JLabel("Direccion:");
		lblDireccion.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblDireccion.setBounds(35, 261, 138, 20);
		add(lblDireccion);
		
		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(183, 264, 192, 20);
		add(txtDireccion);
		
		lblFechaNacimiento = new JLabel("Fecha Nacimiento:");
		lblFechaNacimiento.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblFechaNacimiento.setBounds(35, 292, 138, 20);
		add(lblFechaNacimiento);
		
		lblTelefono = new JLabel("Telefono:");
		lblTelefono.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblTelefono.setBounds(35, 323, 138, 20);
		add(lblTelefono);
		
		txtTelefono = new JTextField();
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(183, 326, 192, 20);
		add(txtTelefono);
		dateChooser.setBounds(183, 294, 192, 20);
		add(dateChooser);

		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String temporal;
					alum.setNombreAlumno(txtNombre.getText());
					alum.setApellido1Alumno(txtApellido1.getText());
					alum.setApellido2Alumno(txtApellido2.getText());
					alum.setDniAlumno(txtDNI.getText());
					alum.setDireccionAlumno(txtDireccion.getText());
					alum.setFechaNacimiento(dateChooser.getJCalendar().getDate());
					temporal = alum.getFechaNacimiento().toLocaleString();
					alum.setTelefonoAlumno(txtTelefono.getText());
					System.out.println(temporal);
					temporal = temporal.replaceFirst(".$","");
					temporal =temporal.replaceFirst(".$","");
					temporal =temporal.replaceFirst(".$","");
					temporal =temporal.replaceFirst(".$","");
					temporal =temporal.replaceFirst(".$","");
					temporal =temporal.replaceFirst(".$","");
					temporal =temporal.replaceFirst(".$","");
					temporal =temporal.replaceFirst(".$","");
					temporal =temporal.replaceFirst(".$","");
					System.out.println(temporal);
					alum.setFechaNacimientoBuena(temporal);
					bd.agregarAlumno(alum);
					JOptionPane.showMessageDialog(null, "EL ALUMNO HA SIDO AGREGADO CORRECTAMENTE", "�ATENCI�N!", JOptionPane.INFORMATION_MESSAGE);
				} catch (NumberFormatException e2) {
					JOptionPane.showMessageDialog(null, "Debe de poner la fecha con espacios(Ejemplo: 1997 24 03)", "�ATENCI�N!", JOptionPane.INFORMATION_MESSAGE);// TODO: handle exception
				}
			}
		});
		
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int valor = JOptionPane.showConfirmDialog(null, "�Est�s seguro de que quieres limpiar los datos introducidos?", "�CUIDADO!", JOptionPane.YES_NO_OPTION);
				
				if(JOptionPane.OK_OPTION == valor) {
					txtNombre.setText("");
					txtApellido1.setText("");
					txtApellido2.setText("");
					txtDNI.setText("");
					txtDireccion.setText("");
					dateChooser.update(null);
					txtTelefono.setText("");
				}
			}
		});
	}
}
